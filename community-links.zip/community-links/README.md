# 🌐 Community Links Hub

Website link komunitas yang cantik, smooth, dan siap deploy ke Vercel!

## ✨ Fitur
- Animasi super smooth dengan Framer Motion
- Particle field interaktif
- Tema biru-hijau yang elegan
- Responsif di mobile dan desktop
- Mudah dikustomisasi
- Deploy 1 klik ke Vercel

---

## 🎨 Cara Kustomisasi

Semua pengaturan ada di satu file:

```
config/community.ts
```

### Yang bisa diubah:
- **Nama komunitas** — `name`
- **Tagline & deskripsi** — `tagline`, `description`
- **Logo** — `logoUrl` (URL gambar) atau `logoInitials` (teks singkatan)
- **Statistik** — `stats` (atau set `null` untuk sembunyikan)
- **Link sosmed** — array `links`
  - Label, sublabel, URL, ikon, warna, jumlah member
- **Footer** — `footerText`, `showMadeWith`

### Menambah link baru:
Tambahkan objek baru di array `links` di `config/community.ts`:
```ts
{
  id: "instagram",
  label: "Instagram",
  sublabel: "Follow akun kami",
  url: "https://instagram.com/username",
  icon: "instagram",      // discord | whatsapp | tiktok | instagram | youtube
  color: "#E1306C",
  gradientFrom: "#E1306C",
  gradientTo: "#F77737",
  glowColor: "rgba(225, 48, 108, 0.4)",
  members: "5K followers",
}
```

---

## 🚀 Deploy ke Vercel

### Cara 1: Via GitHub (Direkomendasikan)
1. Push project ini ke GitHub
2. Buka [vercel.com](https://vercel.com) → New Project
3. Import repo dari GitHub
4. Klik Deploy — selesai!

### Cara 2: Via Vercel CLI
```bash
npm i -g vercel
vercel
```

---

## 💻 Jalankan Lokal

```bash
npm install
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000)

---

## 📁 Struktur File

```
community-links/
├── config/
│   └── community.ts      ← 🎨 EDIT DI SINI
├── components/
│   ├── Icons.tsx          ← Ikon sosmed
│   ├── LinkCard.tsx       ← Kartu link
│   └── ParticleField.tsx  ← Animasi partikel
├── app/
│   ├── page.tsx           ← Halaman utama
│   ├── layout.tsx         ← Layout & metadata
│   └── globals.css        ← Style global
└── README.md
```
