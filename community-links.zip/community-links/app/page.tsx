"use client";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import dynamic from "next/dynamic";
import LinkCard from "@/components/LinkCard";
import { communityConfig } from "@/config/community";

const ParticleField = dynamic(() => import("@/components/ParticleField"), {
  ssr: false,
});

export default function Home() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: containerRef });
  const headerY = useTransform(scrollYProgress, [0, 1], [0, -80]);
  const headerOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0.3]);

  const { name, tagline, description, logoUrl, logoInitials, stats, links, footerText, showMadeWith } = communityConfig;

  return (
    <div
      ref={containerRef}
      className="relative min-h-screen flex flex-col items-center justify-start overflow-x-hidden"
      style={{ background: "var(--bg-primary)" }}
    >
      {/* Grid background */}
      <div className="fixed inset-0 grid-bg opacity-100 pointer-events-none z-0" />

      {/* Ambient orbs */}
      <div
        className="orb w-[500px] h-[500px] top-[-150px] left-[-200px] opacity-20 animate-float"
        style={{ background: "radial-gradient(circle, #0f7c7c, #071826)" }}
      />
      <div
        className="orb w-[400px] h-[400px] top-[10%] right-[-180px] opacity-15 animate-float-delay"
        style={{ background: "radial-gradient(circle, #1a4a8a, #040d14)" }}
      />
      <div
        className="orb w-[600px] h-[600px] bottom-[-200px] left-[50%] -translate-x-1/2 opacity-10 animate-float-delay2"
        style={{ background: "radial-gradient(circle, #14b8a6, #040d14)" }}
      />

      {/* Particles */}
      <ParticleField />

      {/* Main Content */}
      <main className="relative z-10 w-full max-w-lg mx-auto px-4 py-12 md:py-20 flex flex-col items-center">
        {/* Header */}
        <motion.div
          className="flex flex-col items-center mb-10 md:mb-12"
          style={{ y: headerY, opacity: headerOpacity }}
        >
          {/* Logo / Avatar */}
          <motion.div
            className="relative mb-6"
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1] }}
          >
            {/* Outer ring */}
            <div className="absolute inset-0 rounded-full animate-spin-slow"
              style={{
                background: "conic-gradient(from 0deg, #14b8a6, #3b82f6, #06d6d6, transparent, #14b8a6)",
                padding: "2px",
                margin: "-6px",
                borderRadius: "9999px",
              }}
            />
            {/* Glow */}
            <div
              className="absolute inset-0 rounded-full animate-pulse-glow"
              style={{ margin: "-4px", borderRadius: "9999px" }}
            />
            {/* Avatar */}
            <div
              className="relative w-24 h-24 md:w-28 md:h-28 rounded-full flex items-center justify-center text-3xl md:text-4xl font-black"
              style={{
                background: "linear-gradient(135deg, #0d4f4f, #071826)",
                border: "3px solid rgba(20,184,166,0.5)",
                color: "#14b8a6",
                fontFamily: "var(--font-outfit)",
                boxShadow: "inset 0 2px 20px rgba(20,184,166,0.1)",
              }}
            >
              {logoUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={logoUrl} alt={name} className="w-full h-full rounded-full object-cover" />
              ) : (
                <span className="shimmer-text">{logoInitials}</span>
              )}
            </div>
          </motion.div>

          {/* Name */}
          <motion.h1
            className="text-3xl md:text-4xl font-black text-center mb-2 leading-tight"
            style={{ fontFamily: "var(--font-outfit)" }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            <span className="shimmer-text">{name}</span>
          </motion.h1>

          {/* Tagline */}
          <motion.p
            className="text-lg md:text-xl text-teal-300/80 font-medium text-center mb-3"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            {tagline}
          </motion.p>

          {/* Description */}
          <motion.p
            className="text-sm md:text-base text-blue-200/50 text-center max-w-sm leading-relaxed"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            {description}
          </motion.p>

          {/* Stats */}
          {stats && (
            <motion.div
              className="flex items-center gap-4 md:gap-6 mt-6 flex-wrap justify-center"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              {stats.map((stat, i) => (
                <div key={i} className="flex flex-col items-center">
                  <span
                    className="text-xl md:text-2xl font-black"
                    style={{
                      fontFamily: "var(--font-outfit)",
                      background: "linear-gradient(135deg, #14b8a6, #3b82f6)",
                      WebkitBackgroundClip: "text",
                      WebkitTextFillColor: "transparent",
                    }}
                  >
                    {stat.value}
                  </span>
                  <span className="text-xs text-blue-200/40">{stat.label}</span>
                </div>
              ))}
            </motion.div>
          )}
        </motion.div>

        {/* Divider */}
        <motion.div
          className="w-full flex items-center gap-4 mb-6"
          initial={{ opacity: 0, scaleX: 0 }}
          animate={{ opacity: 1, scaleX: 1 }}
          transition={{ duration: 0.8, delay: 0.55 }}
        >
          <div className="flex-1 h-px" style={{ background: "linear-gradient(90deg, transparent, rgba(20,184,166,0.3))" }} />
          <span className="text-xs text-teal-500/60 font-medium tracking-widest uppercase whitespace-nowrap">
            Bergabung Sekarang
          </span>
          <div className="flex-1 h-px" style={{ background: "linear-gradient(270deg, transparent, rgba(20,184,166,0.3))" }} />
        </motion.div>

        {/* Links */}
        <div className="w-full flex flex-col gap-3 md:gap-4">
          {links.map((link, i) => (
            <LinkCard key={link.id} link={link} index={i} />
          ))}
        </div>

        {/* Footer */}
        <motion.div
          className="mt-12 md:mt-16 flex flex-col items-center gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1 }}
        >
          <p className="text-xs text-blue-200/30 text-center">{footerText}</p>
          {showMadeWith && (
            <p className="text-xs text-blue-200/20 text-center">
              Powered by{" "}
              <span className="text-teal-500/50">Next.js</span> &{" "}
              <span className="text-blue-500/50">Vercel</span>
            </p>
          )}
        </motion.div>
      </main>
    </div>
  );
}
