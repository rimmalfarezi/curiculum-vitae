// ============================================================
//  🎨 KONFIGURASI KOMUNITAS — Edit semua di sini!
// ============================================================

export const communityConfig = {
  // --- INFO UTAMA ---
  name: "Komunitas Kita",
  tagline: "Satu tempat, satu komunitas.",
  description:
    "Bergabunglah bersama ribuan anggota yang saling berbagi, belajar, dan bertumbuh bersama.",
  
  // --- AVATAR / LOGO ---
  // Ganti dengan URL gambar logomu, atau biarkan null untuk tampilkan inisial
  logoUrl: null as string | null,
  logoInitials: "KK",

  // --- STATS (opsional, set null untuk sembunyikan) ---
  stats: [
    { label: "Member Aktif", value: "2.4K+" },
    { label: "Pesan Hari Ini", value: "850+" },
    { label: "Konten Baru", value: "120+" },
  ] as { label: string; value: string }[] | null,

  // --- LINK SOSIAL MEDIA ---
  links: [
    {
      id: "discord",
      label: "Discord",
      sublabel: "Gabung server kami",
      url: "https://discord.gg/ganti-link-ini",
      icon: "discord",
      color: "#5865F2",
      gradientFrom: "#5865F2",
      gradientTo: "#7289da",
      glowColor: "rgba(88, 101, 242, 0.4)",
      members: "2.4K online",
    },
    {
      id: "whatsapp",
      label: "WhatsApp",
      sublabel: "Grup komunitas aktif",
      url: "https://chat.whatsapp.com/ganti-link-ini",
      icon: "whatsapp",
      color: "#25D366",
      gradientFrom: "#25D366",
      gradientTo: "#128C7E",
      glowColor: "rgba(37, 211, 102, 0.4)",
      members: "850 member",
    },
    {
      id: "tiktok",
      label: "TikTok",
      sublabel: "Konten seru tiap hari",
      url: "https://www.tiktok.com/@ganti-username",
      icon: "tiktok",
      color: "#ff0050",
      gradientFrom: "#ff0050",
      gradientTo: "#00f2ea",
      glowColor: "rgba(255, 0, 80, 0.4)",
      members: "12K followers",
    },
    // Tambah link baru di sini! Contoh:
    // {
    //   id: "instagram",
    //   label: "Instagram",
    //   sublabel: "Follow akun kami",
    //   url: "https://instagram.com/username",
    //   icon: "instagram",
    //   color: "#E1306C",
    //   gradientFrom: "#E1306C",
    //   gradientTo: "#F77737",
    //   glowColor: "rgba(225, 48, 108, 0.4)",
    //   members: "5K followers",
    // },
  ],

  // --- FOOTER ---
  footerText: "© 2025 Komunitas Kita. Dibuat dengan ❤️",
  showMadeWith: true,
};
