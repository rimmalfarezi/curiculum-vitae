"use client";
import { motion } from "framer-motion";
import { getIcon, ArrowRightIcon } from "./Icons";

interface LinkCardProps {
  link: {
    id: string;
    label: string;
    sublabel: string;
    url: string;
    icon: string;
    color: string;
    gradientFrom: string;
    gradientTo: string;
    glowColor: string;
    members: string;
  };
  index: number;
}

export default function LinkCard({ link, index }: LinkCardProps) {
  return (
    <motion.a
      href={link.url}
      target="_blank"
      rel="noopener noreferrer"
      className="link-card glass-card rounded-2xl p-5 md:p-6 flex items-center gap-4 md:gap-5 cursor-pointer group no-underline"
      initial={{ opacity: 0, y: 40, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{
        duration: 0.6,
        delay: 0.3 + index * 0.12,
        ease: [0.23, 1, 0.32, 1],
      }}
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.98 }}
      style={{
        borderColor: "rgba(20, 184, 166, 0.15)",
      }}
    >
      {/* Icon Container */}
      <motion.div
        className="relative flex-shrink-0 w-14 h-14 md:w-16 md:h-16 rounded-xl flex items-center justify-center"
        style={{
          background: `linear-gradient(135deg, ${link.gradientFrom}22, ${link.gradientTo}22)`,
          border: `1px solid ${link.color}33`,
        }}
        whileHover={{ rotate: [0, -5, 5, 0] }}
        transition={{ duration: 0.4 }}
      >
        {/* glow ring */}
        <motion.div
          className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100"
          style={{
            boxShadow: `0 0 20px ${link.glowColor}, 0 0 40px ${link.glowColor}`,
            background: `radial-gradient(circle, ${link.color}15, transparent 70%)`,
          }}
          transition={{ duration: 0.3 }}
        />
        <div style={{ color: link.color, position: "relative", zIndex: 1 }}>
          {getIcon(link.icon, 28)}
        </div>
      </motion.div>

      {/* Text */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <h3
            className="text-base md:text-lg font-bold text-white truncate"
            style={{ fontFamily: "var(--font-outfit)" }}
          >
            {link.label}
          </h3>
        </div>
        <p className="text-sm text-teal-300/70 truncate">{link.sublabel}</p>
        <div className="flex items-center gap-1.5 mt-1.5">
          <div
            className="w-1.5 h-1.5 rounded-full animate-pulse"
            style={{ backgroundColor: link.color }}
          />
          <span className="text-xs" style={{ color: link.color + "cc" }}>
            {link.members}
          </span>
        </div>
      </div>

      {/* Arrow */}
      <motion.div
        className="flex-shrink-0 opacity-40 group-hover:opacity-100"
        style={{ color: link.color }}
        initial={{ x: 0 }}
        whileHover={{ x: 4 }}
        transition={{ duration: 0.2 }}
      >
        <ArrowRightIcon size={20} />
      </motion.div>
    </motion.a>
  );
}
